import socket
import json,logging,time

def main():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)  # 创建UDP socket对象
    s_addr = ('127.0.0.1', 9999)
    s.bind(s_addr)  # 绑定地址和端口

    logging.info('UDP Server on %s:%s...', s_addr[0], s_addr[1])

    user = {}  # 存放用户字典 {name: addr}

    print('----------服务器已启动-----------')
    print('Bind UDP on ' + str(s_addr))
    print('等待客户端数据...')
    while True:

        try:
            data, addr = s.recvfrom(1024)  # 等待接收客户端消息存放在2个变量data和addr里
            if not data:  # 检查数据是否为空
                print("收到空数据包，继续监听...")
                continue  # 如果为空，跳过当前循环的剩余部分，继续监听
            json_data = json.loads(data.decode('utf-8'))  # 解码和解析JSON数据
            print(json_data)

            if json_data['message_type'] == "init_message":  # 初始化消息
                if json_data['content'] not in user:  # 如果用户不在user字典中
                    user[json_data['content']] = addr  # 添加用户和地址
                    user_list = [i for i in user.keys()]  # 获取当前在线用户列表
                    json_data['online_user'] = f'{user_list}'  # 更新在线用户列表
                    json_str = json.dumps(json_data, ensure_ascii=False)
                    for address in user.values():
                        s.sendto(json_str.encode('utf-8'), address)  # 发送更新后的用户列表到所有客户端
                    print(json_data['content'] + '进入了聊天室')
                    print(f'当前在线用户{user_list}')

            elif json_data['message_type'] == "leave_message":  # 用户离开消息
                if json_data['content'] in user:  # 如果用户在user字典中
                    user.pop(json_data['content'])  # 从字典中移除用户
                    user_list = [i for i in user.keys()]  # 获取当前在线用户列表
                    for address in user.values():
                        s.sendto(data, address)  # 发送离开消息到所有客户端
                    print(json_data['content'] + '离开了聊天室')
                    print(f'当前在线用户{user_list}')
                    continue

            elif json_data['chat_type'] == "normal":  # 普通消息
                if json_data['message_type'] != "file":
                    for address in user.values():
                        if address != addr:  # 不发送给发送者自己
                            s.sendto(data, address)  # 发送消息到其他客户端

            elif json_data['chat_type'] == "private":  # 私聊消息
                recv_user = json_data['recv_user']
                send_user = json_data['send_user']
                if json_data['message_type'] != "file-data":
                    s.sendto(data, user[recv_user])  # 发送私聊消息到接收者客户端

                else:  # 文件传输消息
                    filename = json_data['file_name']
                    data_size = int(json_data['file_length'])
                    print('文件大小为' + str(data_size))
                    recvd_size = 0
                    data_total = b''
                    j = 0
                    while not recvd_size == data_size:  # 接收完整个文件数据
                        j = j + 1
                        if data_size - recvd_size > 1024:
                            data, addr = s.recvfrom(1024)
                            recvd_size += len(data)
                            print('第' + str(j) + '次收到文件数据')
                        else:  # 最后一片
                            data, addr = s.recvfrom(1024)
                            recvd_size = data_size
                            print('第' + str(j) + '次收到文件数据')
                        data_total += data

                    fhead = len(data_total)
                    message = {}
                    message["chat_type"] = "private"
                    message["message_type"] = "file-data"
                    message["file_length"] = str(fhead)
                    message["file_name"] = json_data["file_name"]
                    message["send_user"] = json_data['send_user']
                    message["recv_user"] = json_data['recv_user']
                    message["content"] = ''
                    jsondata = json.dumps(message, ensure_ascii=False)
                    s.sendto(jsondata.encode('utf-8'), user[recv_user])  # 发送文件传输初始化消息

                    print('开始发送文件数据...')
                    for i in range(len(data_total) // 1024 + 1):
                        time.sleep(0.0000000001)  # 防止数据发送太快，服务器来不及接收出错
                        if 1024 * (i + 1) > len(data_total):  # 是否到最后一片
                            s.sendto(data_total[1024 * i:], user[recv_user])  # 发送最后一片数据
                            print('第' + str(i + 1) + '次发送文件数据')
                        else:
                            s.sendto(data_total[1024 * i:1024 * (i + 1)], user[recv_user])  # 发送数据片段
                            print('第' + str(i + 1) + '次发送文件数据')

                    now_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
                    print('%s: "%s" 文件发送完成! from %s:%s [目标:%s] at %s' % (send_user, filename, addr[0], addr[1], user[recv_user], now_time))

        except ConnectionResetError:
            logging.warning('Someone left unexpectedly.')  # 处理连接重置错误



if __name__ == '__main__':
    main()
