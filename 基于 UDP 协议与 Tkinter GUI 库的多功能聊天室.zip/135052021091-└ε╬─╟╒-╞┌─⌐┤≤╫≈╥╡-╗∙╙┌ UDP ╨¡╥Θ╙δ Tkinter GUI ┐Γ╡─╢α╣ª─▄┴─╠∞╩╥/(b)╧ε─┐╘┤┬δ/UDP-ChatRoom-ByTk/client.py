# 客户端
import socket
import threading
import time
from tkinter import scrolledtext
from tkinter.filedialog import askopenfilename
from tkinter.ttk import Treeview
from stickers import *
from login import *
from register import *
import ctypes
import json
import logging
import os
import sys
import time
'''
参数：
    sock：定义一个实例化socket对象
    server：传递的服务器IP和端口
'''
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)  # IPV4,udp传输
server = ('127.0.0.1', 9999)


class ChatClient():
    def __init__(self, name, scr1, scr2, fri_list, obj_emoji):
        """
        初始化聊天客户端的实例。
        :param name: str, 用户名。
        :param scr1: ScrolledText, 聊天室的消息显示区域。
        :param scr2: ScrolledText, 消息输入区域。
        :param fri_list: Treeview, 显示好友列表的组件。
        :param obj_emoji: Emoji, 表情包管理对象。
        """
        self.name = name
        self.scr1 = scr1
        self.scr2 = scr2
        self.fri_list = fri_list
        self.obj_emoji = obj_emoji

    def toSend(self, *args):
        """
        从文本输入框获取文本并发送消息。
        """
        self.msg = self.scr2.get(1.0, 'end').strip()  # 从文本框获取输入的消息
        if self.msg:
            self.send(self.msg)  # 发送消息
            now_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())  # 获取当前时间
            self.scr1.configure(state='normal')
            self.scr1.insert('end', f"{self.name} {now_time}:\n", 'green')  # 在聊天窗口显示消息
            self.scr1.insert('end', self.msg + '\n')
            self.scr1.see('end')  # 滚动到最新消息
            self.scr2.delete('1.0', 'end')  # 清空输入框
            self.scr1.config(state='disabled')
            print(f'{self.name}：成功发送消息', self.msg)
            return "break"

    def toPrivateSend(self, *args):
        """
        发送私聊消息。
        """
        self.msg = self.scr2.get(1.0, 'end').strip()  # 从文本框获取输入的消息
        self.scr2.delete('1.0', 'end')  # 清空输入框
        send_type, send_file = self.private_send(self.msg)  # 发送消息
        if self.msg and self.fri_list.selection():
            now_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())  # 获取当前时间
            tar_name = self.fri_list.selection()[0]  # 获取选中的接收者名字
            self.scr1.configure(state='normal')
            self.scr1.insert('end', f"{self.name} {now_time}:\n", 'green')
            if send_type == 'text':
                self.scr1.insert('end', self.msg + f'  |私聊{tar_name}\n', 'zise')
                print(f'{self.name}：成功发送消息 [私聊]', self.msg)
            else:
                self.scr1.insert('end', f"{send_file} 文件正在发送中，等待对方接收 |目标:{tar_name}\n", 'shengzise')
                print(f'{self.name}：成功发送文件 [私聊]', send_file)
            self.scr1.see('end')
            self.scr1.config(state='disabled')

    def Get_File(self, filename):
        """
        从文件路径解析出路径、文件名和扩展名。
        :param filename: str, 完整的文件路径。
        :return: tuple, 包含文件路径、文件名和扩展名。
        """
        fpath, tempfilename = os.path.split(filename)  # 分离文件名和路径
        fname, extension = os.path.splitext(tempfilename)  # 分离文件名和扩展名
        return fpath, fname, extension, tempfilename

    def send_file(self, fileType, fileName, filePath):
        """
        向选定的接收者发送文件。
        :param fileType: str, 文件类型。
        :param fileName: str, 文件名。
        :param filePath: str, 文件的完整路径。
        """
        selected = self.fri_list.selection()  # 获取选中的接收者
        if not selected:
            messagebox.showinfo('提示', '请选择一个接收者！')
            return
        recv_user = selected[0]
        if recv_user == 'me':
            messagebox.showinfo('提示', '不能向自己发送文件！')
            return

        message = {
            "chat_type": "private",  # 设定消息类型为私聊
            "message_type": "ask-file",
            "file_type": fileType,
            "file_name": fileName,
            "send_user": self.name,
            "recv_user": recv_user,
            "content": filePath
        }
        jsondata = json.dumps(message, ensure_ascii=False)
        sock.sendto(jsondata.encode('utf-8'), server)  # 发送文件请求到服务器
        print(f'{fileName} 文件正在发送中，等待对方接收 |目标:{recv_user}')
        print(f'{fileName} |已成功发送给{recv_user}')

    def cut_data(self, fhead, data):
        for i in range(fhead // 1024 + 1):  # 循环分块发送数据
            time.sleep(0.0000000001)  # 防止数据发送太快，服务器来不及接收出错
            if 1024 * (i + 1) > fhead:  # 检查是否是最后一块数据
                sock.sendto(data[1024 * i:], server)  # 最后一块数据发送
                print('第' + str(i + 1) + '次发送文件数据')
            else:
                sock.sendto(data[1024 * i:1024 * (i + 1)], server)  # 发送数据块
                print('第' + str(i + 1) + '次发送文件数据')

    def succ_recv(self, filename, sourcename):
        now_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())  # 获取当前时间
        self.scr1.configure(state=NORMAL)
        self.scr1.insert("end", "{} {}:\n".format(self.name, now_time), 'green')  # 插入时间和用户名
        self.scr1.insert("end", f'你已成功接收 {filename}文件', 'shengzise')  # 插入成功接收信息
        self.scr1.insert("end", f' |来源:{sourcename}\n', 'zise')  # 插入文件来源信息
        self.scr1.see(END)
        self.scr1.config(state=DISABLED)

    def succ_send(self, recv_user, filename):
        self.scr1.configure(state=NORMAL)
        self.scr1.insert("end", f'{filename}', 'shengzise')  # 插入文件名
        self.scr1.insert("end", f' |已成功发送给{recv_user}\n', 'zise')  # 插入接收用户信息
        self.scr1.see(END)
        self.scr1.config(state=DISABLED)
        print(f'{self.name}：{filename}--文件成功发送文件给', recv_user)  # 打印发送成功信息

    def send(self, msg):
        if msg != '':
            message = {}
            message["chat_type"] = "normal"
            message["message_type"] = "text"
            message["send_user"] = self.name
            message["content"] = msg.strip()
            jsondata = json.dumps(message, ensure_ascii=False)
            sock.sendto(jsondata.encode('utf-8'), server)  # 发送普通文本消息

    def private_send(self, msg):
        fpath, fname, extension, tempfilename = self.Get_File(msg)  # 判断是路径还是信息
        # print(extension)
        if self.fri_list.selection() == ():
            messagebox.showwarning(title='提示', message='你没有选择发送对象！')

        elif str(extension) in ('.py', '.doc', '.txt', '.docx'):  # 发送文件
            self.send_file('normal-file', tempfilename, msg)
            return 'normal-file', tempfilename

        elif str(extension) in ('.jpg', '.png'):  # 发送图片
            self.send_file('image', tempfilename, msg)
            return 'image', tempfilename

        elif str(extension) in ('.avi', '.mp4'):  # 发送视频
            self.send_file('video', tempfilename, msg)
            return 'video', tempfilename

        else:
            message = {}
            message["chat_type"] = "private"
            message["message_type"] = "text"
            message["send_user"] = self.name
            message["recv_user"] = self.fri_list.selection()[0]
            message["content"] = msg.strip()
            jsondata = json.dumps(message, ensure_ascii=False)
            sock.sendto(jsondata.encode('utf-8'), server)  # 发送私聊文本消息
            return 'text', ''

    def recv(self):
        message = {}
        message["message_type"] = "init_message"  # 初始化消息
        message["content"] = self.name  # 包含发送者的名字
        json_str = json.dumps(message, ensure_ascii=False)
        sock.sendto(json_str.encode('utf-8'), server)  # 发送初始化消息到服务器

        while True:
            data = sock.recv(1024)  # 接收数据
            if not data:  # 检查数据是否为空
                print("收到空数据包，继续监听...")
                continue  # 如果为空，跳过当前循环的剩余部分，继续监听

            source = data.decode('utf-8')
            json_data = json.loads(data.decode('utf-8'))  # 解码和解析JSON数据
            now_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())  # 获取当前时间
            self.scr1.configure(state=NORMAL)

            if json_data['message_type'] == "init_message":  # 初始化消息
                self.scr1.insert("end", f'欢迎{json_data["content"]}加入聊天室' + '\n', 'red')
                print(json_data["online_user"])
                user_list = eval(json_data["online_user"])  # 获取在线用户列表
                for user in user_list:
                    if str(user) not in self.fri_list.get_children() and str(user) != self.name:  # 如果用户不在列表中
                        self.fri_list.insert('', 2, str(user), text=str(user).center(24), values=("1"), tags='其他用户')
                print(json_data["content"] + '进入了聊天室...')

            elif json_data['message_type'] == "leave_message":  # 用户离开消息
                self.scr1.insert("end", f'{json_data["content"]}离开了聊天室...' + '\n', 'red')
                if json_data["content"] in self.fri_list.get_children():
                    self.fri_list.delete(json_data["content"])
                print(json_data["content"] + '离开了聊天室...')

            elif json_data['chat_type'] == "normal":  # 普通消息
                if json_data['message_type'] == "text":  # 普通文本消息
                    self.scr1.insert("end", "{} {}:\n".format(json_data['send_user'], now_time), 'green')
                    self.scr1.insert("end", json_data['content'] + '\n')

                elif json_data['message_type'] == "stickers":  # 表情包消息
                    self.scr1.configure(state=NORMAL)
                    self.scr1.insert("end", "{} {}:\n".format(json_data['send_user'], now_time), 'green')
                    dics = self.obj_emoji.dics
                    if json_data['content'] in dics:
                        mes = json_data['content']
                        self.scr1.image_create(END, image=dics[mes])
                        self.scr1.insert("end", '\n', 'zise')
                        self.scr1.see(END)
                    self.scr1.config(state=DISABLED)
                    print(f'收到{json_data["send_user"]}发的表情包：', json_data['content'])

            elif json_data['chat_type'] == "private":  # 私聊消息
                if json_data['message_type'] == "text":  # 私聊文本消息
                    self.scr1.insert("end", "{} {}:\n".format(json_data['send_user'], now_time), 'green')
                    self.scr1.insert("end", json_data['content'])
                    self.scr1.insert("end", f'  |私聊消息\n', 'zise')
                    print(f'[私聊]收到{json_data["send_user"]}的消息：', json_data['content'])

                elif json_data['message_type'] == "stickers":  # 私聊表情包消息
                    self.scr1.configure(state=NORMAL)
                    self.scr1.insert("end", "{} {}:\n".format(json_data['send_user'], now_time), 'green')
                    dics = self.obj_emoji.dics
                    if json_data['content'] in dics:
                        mes = json_data['content']
                        self.scr1.image_create(END, image=dics[mes])
                        self.scr1.insert("end", f'  |私聊消息\n', 'zise')
                        self.scr1.see(END)
                    self.scr1.config(state=DISABLED)
                    print(f'[私聊]收到{json_data["send_user"]}发的表情包：', json_data['content'])

                elif json_data['message_type'] == "ask-file":  # 发送文件请求
                    fileType = json_data["file_type"]
                    self.scr1.configure(state=NORMAL)
                    self.scr1.insert("end", "{} {}:\n".format(json_data["send_user"], now_time), 'green')
                    self.scr1.insert("end", f'正在向你发送一个{fileType}文件...\n', 'shengzise')
                    self.scr1.see(END)
                    self.scr1.config(state=DISABLED)

                    flag = messagebox.askyesno(title='提示',
                                               message=f'{json_data["send_user"]}向你发送了一个{fileType}\n你是否要接收和保存？')
                    if flag:
                        json_data['message_type'] = "isRecv"
                        json_data['isRecv'] = "true"
                        jsondata = json.dumps(json_data, ensure_ascii=False)
                        sock.sendto(jsondata.encode('utf-8'), server)
                    else:
                        json_data['message_type'] = "isRecv"
                        json_data['isRecv'] = "false"
                        jsondata = json.dumps(json_data, ensure_ascii=False)
                        sock.sendto(jsondata.encode('utf-8'), server)
                        self.scr1.configure(state=NORMAL)
                        self.scr1.insert("end", "{} {}:\n".format(self.name, now_time), 'green')
                        self.scr1.insert("end", f'你已拒绝接收{fileType}', 'shengzise')
                        self.scr1.insert("end", f' |来源:{json_data["send_user"]}\n', 'zise')
                        self.scr1.see(END)
                        self.scr1.config(state=DISABLED)

                elif json_data['message_type'] == "isRecv":  # 文件接收确认消息
                    if json_data['isRecv'] == "true":
                        if json_data["file_type"] == 'normal-file':
                            f = open(json_data["content"], 'rb')  # 打开文件，读取文件数据
                            data = f.read()
                            fhead = len(data)
                            print('文件大小:', fhead)

                            message = {}
                            message["chat_type"] = "private"
                            message["message_type"] = "file-data"
                            message["file_length"] = str(fhead)
                            message["file_name"] = json_data["file_name"]
                            message["send_user"] = json_data["send_user"]
                            message["recv_user"] = json_data["recv_user"]
                            message["content"] = ''
                            jsondata = json.dumps(message, ensure_ascii=False)
                            sock.sendto(jsondata.encode('utf-8'), server)

                            print('开始发送文件数据...')
                            self.cut_data(fhead, data)  # 调用cut_data方法分块发送数据
                            print('文件数据已成功发送到服务器！')
                            f.close()
                    else:
                        self.scr1.insert("end", "{} {}:\n".format(json_data["send_user"], now_time), 'green')
                        self.scr1.insert("end", f"对方拒绝接收你发的{json_data['file_name']}文件\n", 'chengse')
                        self.scr1.see(END)

                elif json_data['message_type'] == "file-data":  # 接收文件数据
                    print('正在接收文件')
                    filename = json_data['file_name']
                    data_size = int(json_data['file_length'])
                    print('文件大小为' + str(data_size))
                    recvd_size = 0
                    data_total = b''
                    j = 0
                    while not recvd_size == data_size:
                        j = j + 1
                        if data_size - recvd_size > 1024:
                            data, addr = sock.recvfrom(1024)
                            recvd_size += len(data)
                            print('第' + str(j) + '次收到文件数据')
                        else:  # 最后一片
                            data, addr = sock.recvfrom(1024)
                            recvd_size = data_size
                            print('第' + str(j) + '次收到文件数据')
                        data_total += data

                    f = open(filename, 'wb')  # 以二进制写方式打开文件，保存数据
                    f.write(data_total)
                    f.close()
                    print(filename, '文件接收完成！')
                    self.succ_recv(filename, json_data["send_user"])  # 调用succ_recv方法通知接收成功

                    message = {}
                    message["chat_type"] = "private"
                    message["message_type"] = "Recv_msg"
                    message["Recv_msg"] = "true"
                    message["file_length"] = json_data['file_length']
                    message["file_name"] = json_data["file_name"]
                    message["send_user"] = json_data["recv_user"]
                    message["recv_user"] = json_data["send_user"]
                    jsondata = json.dumps(message, ensure_ascii=False)
                    sock.sendto(jsondata.encode('utf-8'), server)

                elif json_data['message_type'] == "Recv_msg":  # 文件接收确认
                    if json_data['Recv_msg'] == "true":
                        recv_user = json_data['recv_user']
                        filename = json_data['file_name']
                        self.succ_send(recv_user, filename)  # 调用succ_send方法通知发送成功


class ChatUI():
    def __init__(self, root):
        self.root = root

    def JieShu(self):
        flag = messagebox.askokcancel(title='提示', message='你确定要退出聊天室吗？')
        # s.sendto(f":{name} 已退出聊天室...".encode('utf-8'),server)
        if flag:
            message = {}
            message["message_type"] = "leave_message"
            message["content"] = self.name
            jsondata = json.dumps(message, ensure_ascii=False)
            sock.sendto(jsondata.encode('utf-8'), server)
            sys.exit(0)  # 退出程序

    def openfile(self):
        r = askopenfilename(title='打开文件', filetypes=[('All File', '*.*'), ('文本文件', '.txt'), ('python', '*.py *.pyw')])
        self.scr2.insert(INSERT, r)  # 将选中文件的路径插入到输入框中

    def chat(self, usename):
        self.name = usename
        self.root.title('聊天室--用户名:' + self.name)
        sw = self.root.winfo_screenwidth()  # 获取屏幕宽度
        sh = self.root.winfo_screenheight()  # 获取屏幕高度
        w = 1120  # 设置窗口宽度
        h = 720  # 设置窗口高度
        x = (sw - w) / 2  # 计算窗口水平位置
        y = (sh - h) / 2  # 计算窗口垂直位置
        self.root.geometry("%dx%d+%d+%d" % (w, h, (x + 160), y))  # 设置窗口大小和位置
        self.root.iconbitmap(r'images/icon/chat.ico')  # 设置窗口图标

        self.root.resizable(0, 0)  # 窗口设置为不可放大缩小
        # 告诉操作系统使用程序自身的dpi适配
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
        # 获取屏幕的缩放因子
        ScaleFactor = ctypes.windll.shcore.GetScaleFactorForDevice(0)
        # 设置程序缩放
        self.root.tk.call('tk', 'scaling', ScaleFactor / 75)

        self.root.resizable(1, 1)  # 窗口设置为不可放大缩小
        self.scr1 = scrolledtext.ScrolledText(self.root, height=18, font=('黑体', 13))
        self.scr1.tag_config('green', foreground='#008C00', font=('微软雅黑', 10))  # 设置组件字体颜色
        self.scr1.tag_config('red', foreground='red')
        self.scr1.tag_config('zise', foreground='#aaaaff')
        self.scr1.tag_config('shengzise', foreground='#9d4cff')
        self.scr1.tag_config('chengse', foreground='#ff7f27')

        # 创建树形列表
        self.fri_list = Treeview(self.root, height=30, show="tree")
        self.fri_list.insert('', 0, 'online_user', text='在线用户'.center(10, '-'), values=("1"), tags='在线用户')
        if self.name not in self.fri_list.get_children():  # 如果不在列表中
            self.fri_list.insert('', 1, 'me', text=self.name.center(24), values=("1"), tags='自己')  # 自己在列表中颜色为红色
        self.fri_list.grid(row=1, column=2, rowspan=7, sticky=N)
        self.fri_list.tag_configure('在线用户', foreground='#aa5500', font=('黑体', 13))  # 设置组件字体颜色
        self.fri_list.tag_configure('自己', foreground='red', font=('微软雅黑', 10))  # 设置组件字体颜色
        self.fri_list.tag_configure('其他用户', font=('微软雅黑', 10))  # 设置组件字体颜色

        self.scr1.grid(row=1, column=1)
        l0 = Label(self.root, text='')
        l0.grid(row=2)
        l1 = Label(self.root, text='下框输入你要的发送的内容：')
        l1.grid(row=3, column=1)
        self.scr2 = scrolledtext.ScrolledText(self.root, height=6, font=('黑体', 13))
        self.scr2.grid(row=4, column=1)
        l2 = Label(self.root, text='')
        l2.grid(row=5)
        tf = Frame(self.root)
        tf.grid(row=6, column=1)

        obj_emoji = Emoji(self.root, self.send_mark)  # 表情包对象
        chat = ChatClient(self.name, self.scr1, self.scr2, self.fri_list, obj_emoji)  # 聊天客户端对象

        b0 = Button(tf, text=' 表情包 ', command=obj_emoji.express)  # 表情包按钮
        b0.grid(row=1, column=0, padx=20)
        b1 = Button(tf, text=' 群发 ', command=chat.toSend)  # 群发按钮
        b1.grid(row=1, column=1, padx=20)
        b4 = Button(tf, text=' 私聊 ', command=chat.toPrivateSend)  # 私聊按钮
        b4.grid(row=1, column=2, padx=20)
        b2 = Button(tf, text=' 传文件 ', command=self.openfile)  # 传文件按钮
        b2.grid(row=1, column=3, padx=20, pady=20)

        b3 = Button(tf, text=' 退出 ', command=self.JieShu)  # 退出按钮
        b3.grid(row=1, column=7, padx=20)
        tr = threading.Thread(target=chat.recv, args=(), daemon=True)  # 创建接收消息的线程
        # daemon=True 表示创建的子线程守护主线程，主线程退出子线程直接销毁
        tr.start()
        self.root.protocol("WM_DELETE_WINDOW", self.JieShu)  # 设置窗口关闭时的回调函数

    def send_mark(self, exp, dics):
        stick_code = exp  # 获取表情代码
        now_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())  # 获取当前时间
        self.scr1.configure(state=NORMAL)
        self.scr1.insert("end", "{} {}:\n".format(self.name, now_time), 'green')  # 插入发送者信息和时间
        message = {}
        message["message_type"] = "stickers"  # 消息类型为表情包
        message["send_user"] = self.name  # 发送者
        message["content"] = stick_code  # 表情代码

        if self.fri_list.selection() != () and self.fri_list.selection()[0] != 'me':  # 如果选择了用户且不是自己
            message["chat_type"] = "private"  # 私聊消息
            message["recv_user"] = self.fri_list.selection()[0]  # 接收者
            jsondata = json.dumps(message, ensure_ascii=False)
            sock.sendto(jsondata.encode('utf-8'), server)  # 发送私聊表情消息
            self.scr1.image_create(END, image=dics[stick_code])  # 在聊天窗口显示表情
            self.scr1.insert("end", f'  |私聊{self.fri_list.selection()[0]}\n', 'zise')  # 显示私聊信息
            print(f'表情消息:{stick_code}发送成功！[私聊{self.fri_list.selection()[0]}]')
        else:
            message["chat_type"] = "normal"  # 普通消息
            jsondata = json.dumps(message, ensure_ascii=False)
            sock.sendto(jsondata.encode('utf-8'), server)  # 发送普通表情消息
            self.scr1.image_create(END, image=dics[stick_code])  # 在聊天窗口显示表情
            print(f'表情消息:{stick_code}发送成功！')
            self.scr1.insert(END, '\n')  # 换行
        self.scr1.see(END)  # 滚动到最后一行
        self.scr1.config(state=DISABLED)  # 设置聊天窗口为不可编辑状态


if __name__ == '__main__':
    root = Tk()
    Main = ChatUI(root)
    Login(Register, Main.chat, root)
    root.mainloop()
