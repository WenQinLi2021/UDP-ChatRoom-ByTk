from PIL import Image
import os

# 图片目录和目标分辨率
image_dir = 'images/benner'
target_size = (690, 300)

# 遍历目录下的图片文件
for i in range(1, 9):
    file_path = os.path.join(image_dir, f'banner-{i}.jpg')
    try:
        with Image.open(file_path) as img:
            # 修改图片分辨率
            resized_img = img.resize(target_size)
            # 保存修改后的图片
            resized_img.save(file_path)
            print(f'图片 {file_path} 已修改分辨率为 {target_size}.')
    except FileNotFoundError:
        print(f'文件 {file_path} 未找到。')
    except Exception as e:
        print(f'处理图片 {file_path} 时发生错误: {e}')
